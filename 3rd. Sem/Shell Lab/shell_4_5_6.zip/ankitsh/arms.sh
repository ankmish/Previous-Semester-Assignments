#!/bin/sh
echo "Enter the number to be checked "
read a
b=$a
sum=0
while(( $a > 0 ))
do
	rev=`expr $a % 10 |bc`
	a=`expr $a / 10 | bc`
	s=`expr $rev \* $rev \* $rev |bc`
	sum=`expr $sum + $s |bc`
done
#echo $sum
if [ $b -eq $sum ]
then 
echo "Armstrong"
else
echo "Not a Armstrong "
fi
