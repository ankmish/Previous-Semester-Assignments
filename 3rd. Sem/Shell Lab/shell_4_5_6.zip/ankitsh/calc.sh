#!/bin/sh
echo "Enter the first no."
read a
echo "Enter the second no."
read b
select var in add sub multi div exit
do
case $var in 
"add")
s=`expr "scale=2; $a + $b" |bc`
echo "Sum of the number is :$s"
;;
"sub")
s=`expr "scale=2; $a - $b" |bc`
echo "Subtraction of the number is :$s"
;;
"multi")
s=`expr "scale=2; $a * $b" |bc`
echo "Multiplication of the number is :$s"
;;
"div")
if [ b != 0 ]
then
s=`expr "scale=2; $a / $b" |bc`
echo "Division of the number is :$s"
else
echo "Arthimetic Exception"
fi
;;
"exit")
exit 0 
;;
esac
done
