#!/bin/bash
echo "Enter the character to be checked"
read ch
if [ $ch == "a" -o $ch == "e" -o $ch == "i" -o $ch == "o" -o $ch == "u" -o $ch == "A" -o $ch == "E" -o $ch == "I" -o $ch == "O" -o $ch == "U" ]
then 
	echo "Given Character is Vowel"
else
	echo "Its Consonant character"
fi
