#!/bin/sh

echo "Enter the number whose table is to be printed"
read n
for ((i=1 ; i<=10;i++ ))
do
	arr[$i]=`expr $n*$i |bc` 
	echo "${arr[ $i ]}"
done

