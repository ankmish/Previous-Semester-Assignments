#!/bin/sh
echo "Enter the yera to be checked"
read y
if [ `expr $y % 4 |bc` -eq 0 -a `expr $y % 100 |bc` -ne 0 -o `expr $y % 400 |bc` -eq 0 ]
then 
echo "Leap Year"
else
echo "Not a leap year"
fi
