#!/bin/sh
select veh in car van jeep bicycle exit
do
	case $veh in 
	"car")
	echo "Rental is Rs. 20/km"
	;; 
	"van")
	echo "Rental is Rs. 10/km"
	;;
	"jeep")
	echo "Rental is Rs. 5/km"
	;;
	"bicycle")
	echo "Rental is Rs. 0.2/km"
	;;
	"exit")
	exit 0
	;;
	*)
	echo "Wrong choice has been entered by the user"
	;;
esac
done
	
