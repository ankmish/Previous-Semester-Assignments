#!/bin/sh
s=0
echo "Enter the marks of the 3 subjects"
for((i=0; i<3 ;i++))
do
	read m
	s=`expr "scale=2; $m + $m" |bc`
done
	p=`expr "scale=2; $s/3" |bc`
	echo "pecentage = $p"
