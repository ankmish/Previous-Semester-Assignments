#!/bin/sh
echo "Enter the number to be reversed"
read a
sum=0
while(( $a > 0 ))
do 
	rev=`expr $a%10 |bc`
	sum=`expr $sum*10+$rev |bc`
	a=`expr $a/10 |bc`	
done
echo "Reverse of the number is :$sum" 
